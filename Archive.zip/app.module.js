"use strict";
angular.module("RedditApp", []);